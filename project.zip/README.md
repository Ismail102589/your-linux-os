# YOUR Linux OS
Debian + XFCE (proot) অ্যাপ। ভেতরে নিজস্ব VNC ভিউয়ার, আলাদা অ্যাপ লাগে না।
বিল্ড: GitHub Actions (.github/workflows/build.yml)।
