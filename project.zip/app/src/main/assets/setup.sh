#!/bin/bash
# YOUR Linux OS - প্রথমবারের সেটআপ (proot-এর ভেতরে চলে)
export DEBIAN_FRONTEND=noninteractive LANG=C.UTF-8 HOME=/root
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
p() { echo "##PROGRESS $1 $2"; }

p 41 "সিস্টেম প্রস্তুত হচ্ছে…"
mkdir -p /etc/apt/apt.conf.d /etc/dpkg/dpkg.cfg.d /tmp /root
chmod 1777 /tmp
printf 'nameserver 8.8.8.8\nnameserver 1.1.1.1\n' > /etc/resolv.conf
cat > /etc/apt/apt.conf.d/01yourlinux <<'APT'
APT::Sandbox::User "root";
Acquire::Retries "5";
APT::Install-Recommends "false";
APT
echo 'force-unsafe-io' > /etc/dpkg/dpkg.cfg.d/02yourlinux
printf '#!/bin/sh\nexit 101\n' > /usr/sbin/policy-rc.d; chmod +x /usr/sbin/policy-rc.d

p 43 "প্যাকেজ লিস্ট আপডেট হচ্ছে…"
apt-get update || { sleep 5; apt-get update; } || exit 1

install_pkgs() {  # install_pkgs <fatal:1|0> pkgs...
  local fatal=$1; shift
  apt-get install -y --no-install-recommends "$@" && return 0
  apt-get install -y --no-install-recommends --fix-missing "$@" && return 0
  dpkg --configure -a
  apt-get install -y --no-install-recommends "$@" && return 0
  [ "$fatal" = "1" ] && { echo "!! ইনস্টল ব্যর্থ: $*"; exit 1; }
  echo "!! (ঐচ্ছিক) ব্যর্থ: $*"; return 0
}

p 48 "বেসিক টুলস ইনস্টল হচ্ছে…"
install_pkgs 1 ca-certificates curl wget git nano sudo xz-utils procps locales \
  dbus dbus-x11 x11-xserver-utils xauth tigervnc-standalone-server tigervnc-common

p 58 "XFCE ডেস্কটপ ইনস্টল হচ্ছে (সময় লাগবে)…"
install_pkgs 1 xfce4 xfce4-terminal xfce4-whiskermenu-plugin xfce4-taskmanager \
  mousepad thunar xfce4-notifyd

p 72 "আইকন ও ফন্ট ইনস্টল হচ্ছে…"
install_pkgs 0 adwaita-icon-theme gtk2-engines-murrine gnome-themes-extra \
  papirus-icon-theme fonts-noto-core fonts-inter fonts-noto-color-emoji

p 78 "Firefox ও Software Manager ইনস্টল হচ্ছে…"
install_pkgs 0 firefox-esr synaptic

p 85 "WhiteSur থিম ইনস্টল হচ্ছে…"
install_pkgs 0 sassc libglib2.0-dev-bin libxml2-utils
(
  cd /tmp && rm -rf WhiteSur-gtk-theme
  git clone --depth 1 https://github.com/vinceliuice/WhiteSur-gtk-theme.git \
    && cd WhiteSur-gtk-theme && timeout 900 ./install.sh </dev/null
) || echo "!! WhiteSur থিম ব্যর্থ, ডিফল্ট থিম ব্যবহার হবে"
rm -rf /tmp/WhiteSur-gtk-theme

p 93 "ডেস্কটপ সাজানো হচ্ছে…"
THEME=Adwaita
for t in WhiteSur-Light; do
  { [ -d /usr/share/themes/$t ] || [ -d /root/.themes/$t ]; } && THEME=$t
done
ICON=Adwaita; [ -d /usr/share/icons/Papirus ] && ICON=Papirus
FONT="Noto Sans 10"; fc-list 2>/dev/null | grep -qi "Inter" && FONT="Inter 10"
echo "theme=$THEME icon=$ICON font=$FONT"

X=/root/.config/xfce4/xfconf/xfce-perchannel-xml
mkdir -p $X

cat > $X/xsettings.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xsettings" version="1.0">
  <property name="Net" type="empty">
    <property name="ThemeName" type="string" value="$THEME"/>
    <property name="IconThemeName" type="string" value="$ICON"/>
  </property>
  <property name="Gtk" type="empty">
    <property name="FontName" type="string" value="$FONT"/>
  </property>
</channel>
XML

cat > $X/xfwm4.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfwm4" version="1.0">
  <property name="general" type="empty">
    <property name="theme" type="string" value="$THEME"/>
    <property name="button_layout" type="string" value="|HMC"/>
    <property name="use_compositing" type="bool" value="false"/>
    <property name="title_alignment" type="string" value="left"/>
  </property>
</channel>
XML

# উইন্ডোজের মতো নিচের টাস্কবার: স্টার্ট মেনু | চলমান অ্যাপ | ট্রে | ঘড়ি
cat > $X/xfce4-panel.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfce4-panel" version="1.0">
  <property name="configver" type="int" value="2"/>
  <property name="panels" type="array">
    <value type="int" value="1"/>
    <property name="panel-1" type="empty">
      <property name="position" type="string" value="p=10;x=0;y=0"/>
      <property name="length" type="uint" value="100"/>
      <property name="position-locked" type="bool" value="true"/>
      <property name="size" type="uint" value="44"/>
      <property name="plugin-ids" type="array">
        <value type="int" value="1"/>
        <value type="int" value="2"/>
        <value type="int" value="3"/>
        <value type="int" value="4"/>
        <value type="int" value="5"/>
      </property>
    </property>
  </property>
  <property name="plugins" type="empty">
    <property name="plugin-1" type="string" value="whiskermenu"/>
    <property name="plugin-2" type="string" value="tasklist"/>
    <property name="plugin-3" type="string" value="separator">
      <property name="expand" type="bool" value="true"/>
      <property name="style" type="uint" value="0"/>
    </property>
    <property name="plugin-4" type="string" value="systray"/>
    <property name="plugin-5" type="string" value="clock"/>
  </property>
</channel>
XML

# ওয়ালপেপার: নীল গ্রেডিয়েন্ট
{
echo '<?xml version="1.0" encoding="UTF-8"?>'
echo '<channel name="xfce4-desktop" version="1.0"><property name="backdrop" type="empty"><property name="screen0" type="empty">'
for m in monitorVNC-0 monitor0 monitorscreen; do
cat <<XML
<property name="$m" type="empty"><property name="workspace0" type="empty">
<property name="color-style" type="int" value="2"/>
<property name="image-style" type="int" value="0"/>
<property name="rgba1" type="array"><value type="double" value="0.07"/><value type="double" value="0.22"/><value type="double" value="0.55"/><value type="double" value="1"/></property>
<property name="rgba2" type="array"><value type="double" value="0.02"/><value type="double" value="0.06"/><value type="double" value="0.20"/><value type="double" value="1"/></property>
</property></property>
XML
done
echo '</property></property></channel>'
} > $X/xfce4-desktop.xml

cat > /etc/profile.d/yourlinux.sh <<'PROF'
export MOZ_FAKE_NO_SANDBOX=1 MOZ_DISABLE_CONTENT_SANDBOX=1 MOZ_DISABLE_GMP_SANDBOX=1
export LIBGL_ALWAYS_SOFTWARE=1 NO_AT_BRIDGE=1 QT_X11_NO_MITSHM=1 _X11_NO_MITSHM=1
PROF

touch /root/.setup_done
p 100 "সেটআপ সম্পন্ন!"
