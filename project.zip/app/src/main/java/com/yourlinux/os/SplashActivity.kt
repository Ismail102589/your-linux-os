package com.yourlinux.os

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.max
import kotlin.math.min

class SplashActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private val t0 = SystemClock.uptimeMillis()
    private var launched = false

    private lateinit var status: TextView
    private lateinit var hint: TextView
    private lateinit var bar: ProgressBar
    private lateinit var logScroll: ScrollView
    private lateinit var logView: TextView
    private lateinit var buttons: LinearLayout

    private val listener: () -> Unit = { ui.post { render() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        SessionState.addListener(listener)
        render()
        startLinux(LinuxService.ACTION_START)
    }

    override fun onDestroy() {
        SessionState.removeListener(listener)
        super.onDestroy()
    }

    private fun geometry(): String {
        val dm = resources.displayMetrics
        val long = max(dm.widthPixels, dm.heightPixels).toFloat()
        val short = min(dm.widthPixels, dm.heightPixels).toFloat()
        val k = min(1f, 1280f / long)
        var w = ((long * k).toInt() / 8) * 8
        var h = ((short * k).toInt() / 2) * 2
        if (w < 800) w = 800
        if (h < 450) h = 450
        return "${w}x${h}"
    }

    private fun startLinux(action: String) {
        val i = Intent(this, LinuxService::class.java)
            .setAction(action)
            .putExtra(LinuxService.EXTRA_GEOMETRY, geometry())
        startForegroundService(i)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            adjustViewBounds = true
        }
        root.addView(logo, LinearLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT))

        status = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#1a1a1a"))
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(8))
        }
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)))

        hint = TextView(this).apply {
            text = "প্রথমবার ১-২ GB ডাউনলোড ও সেটআপ হবে (২০-৪০ মিনিট)। WiFi ব্যবহার করুন, স্ক্রিন চালু রাখুন।"
            textSize = 12f
            setTextColor(Color.parseColor("#666666"))
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        root.addView(hint)

        logView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 10f
            setTextColor(Color.parseColor("#333333"))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        logScroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#F1F1F1"))
            addView(logView)
        }
        root.addView(logScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(160)).apply { topMargin = dp(12) })

        buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        buttons.addView(Button(this).apply {
            text = "আবার চেষ্টা"
            setOnClickListener { startLinux(LinuxService.ACTION_START) }
        })
        buttons.addView(Button(this).apply {
            text = "লগ কপি"
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("log", SessionState.logText()))
                Toast.makeText(this@SplashActivity, "লগ কপি হয়েছে", Toast.LENGTH_SHORT).show()
            }
        })
        buttons.addView(Button(this).apply {
            text = "রিসেট"
            setOnClickListener {
                AlertDialog.Builder(this@SplashActivity)
                    .setMessage("সব মুছে নতুন করে ইনস্টল করবেন?")
                    .setPositiveButton("হ্যাঁ") { _, _ -> startLinux(LinuxService.ACTION_RESET) }
                    .setNegativeButton("না", null)
                    .show()
            }
        })
        root.addView(buttons)
        setContentView(root)
    }

    private fun render() {
        val ph = SessionState.phase
        val msg = SessionState.message
        status.text = if (msg.isNotEmpty()) msg else "শুরু হচ্ছে…"
        status.setTextColor(if (ph == Phase.ERROR) Color.parseColor("#C62828") else Color.parseColor("#1a1a1a"))
        bar.progress = SessionState.progress
        bar.visibility = if (ph == Phase.ERROR) View.INVISIBLE else View.VISIBLE

        val setup = ph == Phase.DOWNLOADING || ph == Phase.EXTRACTING || ph == Phase.CONFIGURING
        logScroll.visibility = if (setup || ph == Phase.ERROR) View.VISIBLE else View.GONE
        if (logScroll.visibility == View.VISIBLE) {
            logView.text = SessionState.logTail(60)
            logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
        }
        buttons.visibility = if (ph == Phase.ERROR) View.VISIBLE else View.GONE
        val first = !File(filesDir, "rootfs/root/.setup_done").exists()
        hint.visibility = if (first && ph != Phase.ERROR) View.VISIBLE else View.GONE

        if (ph == Phase.RUNNING && !launched) {
            launched = true
            val wait = max(0L, 2000L - (SystemClock.uptimeMillis() - t0))
            ui.postDelayed({
                startActivity(Intent(this, DesktopActivity::class.java))
                finish()
            }, wait)
        }
    }
}
