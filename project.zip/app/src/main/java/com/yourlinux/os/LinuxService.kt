package com.yourlinux.os

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.IBinder
import android.os.PowerManager
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket

class LinuxService : Service() {
    companion object {
        const val ACTION_START = "com.yourlinux.os.START"
        const val ACTION_STOP = "com.yourlinux.os.STOP"
        const val ACTION_RESET = "com.yourlinux.os.RESET"
        const val EXTRA_GEOMETRY = "geometry"
        const val VNC_PORT = 5901
        private const val CH = "yourlinux"
        private const val NOTIF_ID = 1
    }

    private var worker: Thread? = null
    @Volatile private var sessionProc: Process? = null
    @Volatile private var stopping = false
    private var geometry = "1280x576"
    private var wake: PowerManager.WakeLock? = null
    private val listener: () -> Unit = { updateNotification() }

    override fun onCreate() {
        super.onCreate()
        SessionState.addListener(listener)
    }

    override fun onDestroy() {
        SessionState.removeListener(listener)
        killSession()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification(SessionState.message.ifEmpty { "শুরু হচ্ছে…" }))
        intent?.getStringExtra(EXTRA_GEOMETRY)?.let { geometry = it }
        when (intent?.action) {
            ACTION_STOP -> {
                killSession()
                SessionState.update(Phase.IDLE, 0, "")
                stopForeground(true)
                stopSelf()
            }
            ACTION_RESET -> Thread {
                killSession()
                worker?.join(5000)
                val env = Env(this)
                env.deleteTree(env.rootfs)
                env.deleteTree(env.state)
                SessionState.clearLog()
                SessionState.update(Phase.IDLE, 0, "রিসেট হয়েছে")
                startPipeline()
            }.start()
            else -> startPipeline()
        }
        return START_NOT_STICKY
    }

    private fun startPipeline() {
        if (worker?.isAlive == true) return
        stopping = false
        worker = Thread({ runPipeline() }, "yourlinux-pipeline").also { it.start() }
    }

    private fun runPipeline() {
        val env = Env(this)
        try {
            acquireWake()
            env.prepare()
            if (!env.prootBin.exists()) {
                throw IOException("proot ফাইল APK-তে নেই (libproot.so)। GitHub Actions-এর 'Fetch proot' ধাপ দেখুন।")
            }
            val existing = sessionProc
            if (existing != null && existing.isAlive) {
                SessionState.update(Phase.STARTING, 100, "ডেস্কটপ চালু হচ্ছে…")
                awaitDesktop(env, existing)
                return
            }
            if (!env.rootfsReadyFlag.exists()) {
                if (env.files.usableSpace < 3L * 1024 * 1024 * 1024) {
                    throw IOException("ফোনে অন্তত ৩ GB ফাঁকা জায়গা দরকার")
                }
                SessionState.clearLog()
                SessionState.update(Phase.DOWNLOADING, 0, "Linux ডাউনলোড হচ্ছে…")
                env.deleteTree(env.rootfs)
                env.rootfs.mkdirs()
                val archive = RootfsInstaller.download(env) { pct, msg ->
                    SessionState.update(Phase.DOWNLOADING, pct * 30 / 100, msg)
                }
                SessionState.update(Phase.EXTRACTING, 30, "ফাইল এক্সট্র্যাক্ট হচ্ছে…")
                RootfsInstaller.extract(archive, env.rootfs) { pct ->
                    SessionState.update(Phase.EXTRACTING, 30 + pct * 10 / 100, "ফাইল এক্সট্র্যাক্ট হচ্ছে… $pct%")
                }
                archive.delete()
                RootfsInstaller.finalizeRootfs(this, env)
                env.rootfsReadyFlag.writeText("ok")
            }
            RootfsInstaller.installScripts(this, env)
            if (!env.setupDoneFlag.exists()) runSetup(env)
            startSession(env)
        } catch (e: Throwable) {
            if (!stopping) {
                SessionState.log("ত্রুটি: ${e.message ?: e}")
                SessionState.update(Phase.ERROR, message = e.message ?: e.toString())
            }
        }
    }

    private fun runSetup(env: Env) {
        SessionState.update(Phase.CONFIGURING, 40, "ডেস্কটপ ও অ্যাপ ইনস্টল হচ্ছে (অনেক সময় লাগবে)…")
        val p = env.prootProcess(listOf("/bin/bash", "/root/setup.sh")).start()
        sessionProc = p
        try {
            BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).forEachLine { line ->
                if (line.startsWith("##PROGRESS ")) {
                    val parts = line.split(" ", limit = 3)
                    val pct = parts.getOrNull(1)?.toIntOrNull()
                    val msg = parts.getOrNull(2) ?: ""
                    SessionState.update(Phase.CONFIGURING, pct, if (msg.isEmpty()) null else msg)
                } else {
                    SessionState.log(line)
                }
            }
            val code = p.waitFor()
            if (!env.setupDoneFlag.exists()) {
                throw IOException("সেটআপ সম্পূর্ণ হয়নি (কোড $code)। লগ দেখে 'আবার চেষ্টা' চাপুন।")
            }
        } finally {
            sessionProc = null
        }
    }

    private fun startSession(env: Env) {
        SessionState.update(Phase.STARTING, 100, "ডেস্কটপ চালু হচ্ছে…")
        env.desktopReadyFlag.delete()
        val p = env.prootProcess(
            listOf("/bin/bash", "/root/start-desktop.sh"),
            listOf("VNC_GEOMETRY=$geometry")
        ).start()
        sessionProc = p
        Thread({
            try {
                BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).forEachLine { SessionState.log(it) }
            } catch (_: Exception) {}
            val code = try { p.waitFor() } catch (_: Exception) { -1 }
            if (!stopping && sessionProc === p) {
                SessionState.update(Phase.ERROR, message = "Linux সেশন বন্ধ হয়ে গেছে (কোড $code)")
            }
        }, "yourlinux-session").start()
        awaitDesktop(env, p)
    }

    private fun awaitDesktop(env: Env, p: Process) {
        val deadline = System.currentTimeMillis() + 240_000
        while (System.currentTimeMillis() < deadline) {
            if (!p.isAlive) throw IOException("ডেস্কটপ চালু হয়নি। লগ দেখুন।")
            if (env.desktopReadyFlag.exists() && portOpen()) {
                SessionState.update(Phase.RUNNING, 100, "প্রস্তুত")
                return
            }
            Thread.sleep(700)
        }
        throw IOException("ডেস্কটপ চালু হতে অনেক সময় লাগছে (টাইমআউট)। 'আবার চেষ্টা' চাপুন।")
    }

    private fun portOpen(): Boolean = try {
        Socket().use { it.connect(InetSocketAddress("127.0.0.1", VNC_PORT), 300) }
        true
    } catch (_: Exception) { false }

    private fun killSession() {
        stopping = true
        try { sessionProc?.destroyForcibly() } catch (_: Exception) {}
        sessionProc = null
        try { wake?.release() } catch (_: Exception) {}
        wake = null
    }

    private fun acquireWake() {
        if (wake == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "yourlinux:session").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun updateNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(SessionState.message.ifEmpty { "YOUR Linux OS" }))
    }

    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "YOUR Linux OS", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, SplashActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getForegroundService(
            this, 1, Intent(this, LinuxService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setContentTitle("YOUR Linux OS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_delete), "বন্ধ করুন", stop
                ).build()
            )
            .build()
    }
}
