package com.yourlinux.os

import android.content.Context
import android.system.Os
import java.io.File
import java.io.IOException
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.SimpleFileVisitor
import java.nio.file.attribute.BasicFileAttributes

class Env(ctx: Context) {
    val files: File = ctx.filesDir
    val rootfs = File(files, "rootfs")
    val tmp = File(files, "tmp")
    val libs = File(files, "libs")
    val state = File(files, "state")
    val nativeDir: String = ctx.applicationInfo.nativeLibraryDir

    val prootBin = File(nativeDir, "libproot.so")
    val rootfsReadyFlag = File(state, "rootfs_ready")
    val setupDoneFlag: File get() = File(rootfs, "root/.setup_done")
    val desktopReadyFlag: File get() = File(rootfs, "tmp/.desktop_ready")

    fun prepare() {
        for (d in listOf(tmp, libs, state, rootfs)) d.mkdirs()
        val link = File(libs, "libtalloc.so.2")
        try { Os.remove(link.path) } catch (_: Exception) {}
        try {
            Os.symlink("$nativeDir/libtalloc.so", link.path)
        } catch (e: Exception) {
            throw IOException("symlink ব্যর্থ: ${e.message}")
        }
    }

    /** rootfs-এর ভেতরে proot দিয়ে কমান্ড চালানোর ProcessBuilder */
    fun prootProcess(command: List<String>, extraEnv: List<String> = emptyList()): ProcessBuilder {
        val args = ArrayList<String>()
        args += prootBin.absolutePath
        args += listOf(
            "--link2symlink", "--kill-on-exit", "--root-id", "--sysvipc",
            "--kernel-release=5.4.0-yourlinux",
            "--rootfs=${rootfs.absolutePath}",
            "--cwd=/root",
            "--bind=/dev", "--bind=/proc", "--bind=/sys",
            "--bind=${File(rootfs, "tmp").absolutePath}:/dev/shm"
        )
        if (File("/storage/emulated/0").exists()) args += "--bind=/storage/emulated/0:/sdcard"
        args += listOf(
            "/usr/bin/env", "-i",
            "HOME=/root", "USER=root", "LOGNAME=root", "LANG=C.UTF-8",
            "TERM=xterm-256color", "TMPDIR=/tmp",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        )
        args += extraEnv
        args += command

        val pb = ProcessBuilder(args)
        pb.environment().apply {
            put("PROOT_LOADER", "$nativeDir/libproot-loader.so")
            put("PROOT_TMP_DIR", tmp.absolutePath)
            put("PROOT_NO_SECCOMP", "1")
            put("LD_LIBRARY_PATH", libs.absolutePath)
        }
        pb.directory(files)
        pb.redirectErrorStream(true)
        return pb
    }

    /** symlink অনুসরণ না করে ফোল্ডার মোছা */
    fun deleteTree(f: File) {
        if (!f.exists() && !Files.isSymbolicLink(f.toPath())) return
        Files.walkFileTree(f.toPath(), object : SimpleFileVisitor<Path>() {
            override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                try { Files.deleteIfExists(file) } catch (_: Exception) {}
                return FileVisitResult.CONTINUE
            }
            override fun visitFileFailed(file: Path, exc: IOException): FileVisitResult = FileVisitResult.CONTINUE
            override fun postVisitDirectory(dir: Path, exc: IOException?): FileVisitResult {
                try { Files.deleteIfExists(dir) } catch (_: Exception) {}
                return FileVisitResult.CONTINUE
            }
        })
    }
}
