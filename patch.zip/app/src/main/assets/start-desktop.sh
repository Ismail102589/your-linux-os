#!/bin/bash
export HOME=/root USER=root LOGNAME=root LANG=C.UTF-8 SHELL=/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export XDG_RUNTIME_DIR=/tmp/runtime-root XDG_CURRENT_DESKTOP=XFCE
export MOZ_FAKE_NO_SANDBOX=1 MOZ_DISABLE_CONTENT_SANDBOX=1 MOZ_DISABLE_GMP_SANDBOX=1
export LIBGL_ALWAYS_SOFTWARE=1 NO_AT_BRIDGE=1 QT_X11_NO_MITSHM=1 _X11_NO_MITSHM=1
export XCURSOR_SIZE=32
GEOM="${VNC_GEOMETRY:-1600x720}"

pkill -x Xtigervnc 2>/dev/null
rm -rf /tmp/.X1-lock /tmp/.X11-unix/X1 /tmp/.desktop_ready "$XDG_RUNTIME_DIR"
mkdir -p "$XDG_RUNTIME_DIR" /tmp/.X11-unix
chmod 700 "$XDG_RUNTIME_DIR"; chmod 1777 /tmp/.X11-unix

Xtigervnc :1 -geometry "$GEOM" -depth 24 -dpi 120 -rfbport 5901 -localhost \
  -SecurityTypes None -AlwaysShared -ac -nolisten tcp -desktop "YOUR Linux OS" \
  >/tmp/xvnc.log 2>&1 &
XVNC=$!

for i in $(seq 1 60); do [ -S /tmp/.X11-unix/X1 ] && break; sleep 0.5; done
export DISPLAY=:1
xset s off -dpms 2>/dev/null

dbus-launch --exit-with-session startxfce4 >/tmp/xfce.log 2>&1 &
XFCE=$!

for i in $(seq 1 150); do pgrep -x xfce4-panel >/dev/null && break; sleep 1; done
sleep 3
touch /tmp/.desktop_ready

wait $XFCE
kill $XVNC 2>/dev/null
exit 0
