package com.yourlinux.os

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.max
import kotlin.math.min

class SplashActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private val t0 = SystemClock.uptimeMillis()
    private var launched = false

    private lateinit var status: TextView
    private lateinit var hint: TextView
    private lateinit var bar: ProgressBar
    private lateinit var logScroll: ScrollView
    private lateinit var logView: TextView
    private lateinit var buttons: LinearLayout

    private val listener: () -> Unit = { ui.post { render() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.parseColor("#0B1B3A")
        window.navigationBarColor = Color.parseColor("#0E6B6B")
        buildUi()
        SessionState.addListener(listener)
        render()
        askPermissions()
        startLinux(LinuxService.ACTION_START)
    }

    override fun onDestroy() {
        SessionState.removeListener(listener)
        super.onDestroy()
    }

    private fun askPermissions() {
        val need = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:$packageName"))
                )
            }
        } catch (_: Exception) {}
    }

    private fun geometry(): String {
        val dm = resources.displayMetrics
        val long = max(dm.widthPixels, dm.heightPixels).toFloat()
        val short = min(dm.widthPixels, dm.heightPixels).toFloat()
        val cap = getSharedPreferences("yl", MODE_PRIVATE).getInt("cap", 1280)
        val k = min(1f, cap.toFloat() / long)
        var w = ((long * k).toInt() / 8) * 8
        var h = ((short * k).toInt() / 2) * 2
        if (w < 960) w = 960
        if (h < 480) h = 480
        return "${w}x${h}"
    }

    private fun startLinux(action: String) {
        val i = Intent(this, LinuxService::class.java)
            .setAction(action)
            .putExtra(LinuxService.EXTRA_GEOMETRY, geometry())
        startForegroundService(i)
    }

    private fun pill(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 14f
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(10), dp(16), dp(10))
        background = Glass.pressable(this@SplashActivity)
        setOnClickListener { onClick() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#0B1B3A"), Color.parseColor("#0F3D6E"), Color.parseColor("#0E6B6B"))
            )
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            adjustViewBounds = true
            alpha = 0f
            scaleX = 0.92f
            scaleY = 0.92f
        }
        root.addView(logo, LinearLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT))
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start()

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Glass.card(this@SplashActivity)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }

        status = TextView(this).apply {
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(10))
        }
        card.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(Color.parseColor("#7CFFB2"))
            progressBackgroundTintList = ColorStateList.valueOf(Color.argb(80, 255, 255, 255))
        }
        card.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)))

        hint = TextView(this).apply {
            text = "প্রথমবার ১-২ GB ডাউনলোড ও সেটআপ হবে (৪০-৬০ মিনিট)। WiFi ও চার্জার ব্যবহার করুন, স্ক্রিন চালু রাখুন।"
            textSize = 12f
            setTextColor(Color.argb(190, 255, 255, 255))
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        card.addView(hint)

        logView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 10f
            setTextColor(Color.parseColor("#CFE8FF"))
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        logScroll = ScrollView(this).apply {
            background = Glass.shape(
                this@SplashActivity, 12, Color.argb(120, 0, 0, 0), Color.argb(150, 0, 0, 0), Color.argb(45, 255, 255, 255)
            )
            addView(logView)
        }
        card.addView(logScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(150)).apply {
            topMargin = dp(12)
        })
        root.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(14)
        })

        buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val bp = { LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(4), dp(14), dp(4), 0) } }
        buttons.addView(pill("আবার চেষ্টা") { startLinux(LinuxService.ACTION_START) }, bp())
        buttons.addView(pill("লগ কপি") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", SessionState.logText()))
            Toast.makeText(this, "লগ কপি হয়েছে", Toast.LENGTH_SHORT).show()
        }, bp())
        buttons.addView(pill("রিসেট") {
            Glass.show(
                this,
                Glass.dialogBuilder(this)
                    .setMessage("সব মুছে নতুন করে ইনস্টল করবেন?")
                    .setPositiveButton("হ্যাঁ") { _, _ -> startLinux(LinuxService.ACTION_RESET) }
                    .setNegativeButton("না", null)
            )
        }, bp())
        root.addView(buttons)

        val footer = TextView(this).apply {
            text = "YOUR Linux OS  v1.4"
            textSize = 11f
            setTextColor(Color.argb(120, 255, 255, 255))
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun render() {
        val ph = SessionState.phase
        val msg = SessionState.message
        status.text = if (msg.isNotEmpty()) msg else "শুরু হচ্ছে…"
        status.setTextColor(if (ph == Phase.ERROR) Color.parseColor("#FFB4AB") else Color.WHITE)
        bar.progress = SessionState.progress
        bar.visibility = if (ph == Phase.ERROR) View.INVISIBLE else View.VISIBLE

        val setup = ph == Phase.DOWNLOADING || ph == Phase.EXTRACTING || ph == Phase.CONFIGURING
        logScroll.visibility = if (setup || ph == Phase.ERROR) View.VISIBLE else View.GONE
        if (logScroll.visibility == View.VISIBLE) {
            logView.text = SessionState.logTail(60)
            logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
        }
        buttons.visibility = if (ph == Phase.ERROR) View.VISIBLE else View.GONE
        val first = !File(filesDir, "rootfs/root/.setup_done").exists()
        hint.visibility = if (first && ph != Phase.ERROR) View.VISIBLE else View.GONE

        if (ph == Phase.RUNNING && !launched) {
            launched = true
            val wait = max(0L, 2000L - (SystemClock.uptimeMillis() - t0))
            ui.postDelayed({
                startActivity(Intent(this, DesktopActivity::class.java))
                finish()
            }, wait)
        }
    }
}
