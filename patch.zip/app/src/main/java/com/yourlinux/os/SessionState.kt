package com.yourlinux.os

enum class Phase { IDLE, DOWNLOADING, EXTRACTING, CONFIGURING, STARTING, RUNNING, ERROR }

/** Service ও Activity-র মধ্যে অবস্থা শেয়ার করার জায়গা */
object SessionState {
    @Volatile var phase: Phase = Phase.IDLE
    @Volatile var progress: Int = 0
    @Volatile var message: String = ""

    private val buf = StringBuilder()
    private val listeners = ArrayList<() -> Unit>()

    fun addListener(l: () -> Unit) { synchronized(listeners) { listeners.add(l) } }
    fun removeListener(l: () -> Unit) { synchronized(listeners) { listeners.remove(l) } }

    fun update(phase: Phase? = null, progress: Int? = null, message: String? = null) {
        if (phase != null) this.phase = phase
        if (progress != null) this.progress = progress
        if (message != null) this.message = message
        fire()
    }

    fun log(line: String) {
        synchronized(buf) {
            buf.append(line).append('\n')
            if (buf.length > 30000) buf.delete(0, buf.length - 20000)
        }
        fire()
    }

    fun clearLog() { synchronized(buf) { buf.setLength(0) } }
    fun logText(): String = synchronized(buf) { buf.toString() }
    fun logTail(n: Int): String = logText().trimEnd().split('\n').takeLast(n).joinToString("\n")

    private fun fire() {
        val copy = synchronized(listeners) { ArrayList(listeners) }
        for (l in copy) l()
    }
}
