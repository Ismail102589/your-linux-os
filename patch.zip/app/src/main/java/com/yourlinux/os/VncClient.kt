package com.yourlinux.os

import android.graphics.Bitmap
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.EOFException
import java.io.IOException
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

/** ছোট RFB (VNC) ক্লায়েন্ট: Raw + CopyRect, পাসওয়ার্ড ছাড়া (localhost) */
class VncClient(
    private val host: String,
    private val port: Int,
    private val listener: Listener
) {
    interface Listener {
        fun onConnected(width: Int, height: Int)
        fun onFrame()
        fun onDisconnected(reason: String)
    }

    val lock = Any()
    @Volatile var bitmap: Bitmap? = null
    @Volatile private var running = false
    @Volatile private var ready = false
    private var socket: Socket? = null
    private var out: OutputStream? = null
    private val sender = Executors.newSingleThreadExecutor()
    private var fbW = 0
    private var fbH = 0
    private var pixels = IntArray(0)
    private var rawBuf = ByteArray(0)

    private val alpha = 0xFF000000.toInt()

    fun start() {
        running = true
        Thread({ readLoop() }, "vnc-reader").start()
    }

    private fun readLoop() {
        var reason = "সংযোগ বিচ্ছিন্ন"
        try {
            val s = Socket()
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(host, port), 5000)
            socket = s
            val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 1 shl 16))
            out = BufferedOutputStream(s.getOutputStream())
            handshake(inp)
            while (running) {
                when (val t = inp.readUnsignedByte()) {
                    0 -> readUpdate(inp)
                    1 -> { // SetColourMapEntries
                        inp.readUnsignedByte(); inp.readUnsignedShort()
                        val n = inp.readUnsignedShort()
                        skipFully(inp, n * 6L)
                    }
                    2 -> {} // Bell
                    3 -> { // ServerCutText
                        skipFully(inp, 3)
                        val len = inp.readInt()
                        skipFully(inp, len.toLong())
                    }
                    else -> throw IOException("অজানা মেসেজ $t")
                }
            }
        } catch (e: Exception) {
            reason = e.message ?: e.toString()
        } finally {
            val was = running
            close()
            if (was) listener.onDisconnected(reason)
        }
    }

    private fun handshake(inp: DataInputStream) {
        val o = out!!
        val ver = ByteArray(12)
        inp.readFully(ver)
        if (!String(ver).startsWith("RFB")) throw IOException("RFB সার্ভার নয়")
        o.write("RFB 003.008\n".toByteArray()); o.flush()

        val n = inp.readUnsignedByte()
        if (n == 0) {
            val len = inp.readInt().coerceIn(0, 4096)
            val msg = ByteArray(len); inp.readFully(msg)
            throw IOException(String(msg))
        }
        val types = ByteArray(n); inp.readFully(types)
        if (!types.contains(1)) throw IOException("সার্ভারে পাসওয়ার্ড লাগছে")
        o.write(1); o.flush()
        if (inp.readInt() != 0) throw IOException("সিকিউরিটি ব্যর্থ")
        o.write(1); o.flush() // ClientInit: shared

        fbW = inp.readUnsignedShort()
        fbH = inp.readUnsignedShort()
        val pf = ByteArray(16); inp.readFully(pf)
        val nameLen = inp.readInt().coerceIn(0, 4096)
        val nm = ByteArray(nameLen); inp.readFully(nm)

        pixels = IntArray(fbW * fbH)
        synchronized(lock) { bitmap = Bitmap.createBitmap(fbW, fbH, Bitmap.Config.ARGB_8888) }

        // SetPixelFormat: 32bpp, depth 24, little-endian, true colour, R<<16 G<<8 B
        o.write(byteArrayOf(0, 0, 0, 0, 32, 24, 0, 1, 0, -1, 0, -1, 0, -1, 16, 8, 0, 0, 0, 0))
        // SetEncodings: CopyRect(1), Raw(0)
        o.write(byteArrayOf(2, 0, 0, 2, 0, 0, 0, 1, 0, 0, 0, 0))
        o.flush()
        ready = true
        requestUpdate(false)
        listener.onConnected(fbW, fbH)
    }

    private fun readUpdate(inp: DataInputStream) {
        inp.readUnsignedByte()
        val n = inp.readUnsignedShort()
        var x1 = Int.MAX_VALUE; var y1 = Int.MAX_VALUE; var x2 = 0; var y2 = 0
        for (i in 0 until n) {
            val x = inp.readUnsignedShort()
            val y = inp.readUnsignedShort()
            val w = inp.readUnsignedShort()
            val h = inp.readUnsignedShort()
            val enc = inp.readInt()
            if (x + w > fbW || y + h > fbH) throw IOException("রেক্ট সীমার বাইরে")
            when (enc) {
                0 -> readRaw(inp, x, y, w, h)
                1 -> {
                    val sx = inp.readUnsignedShort()
                    val sy = inp.readUnsignedShort()
                    if (sx + w > fbW || sy + h > fbH) throw IOException("copyrect সীমার বাইরে")
                    copyRect(sx, sy, x, y, w, h)
                }
                else -> throw IOException("অসমর্থিত এনকোডিং $enc")
            }
            if (w > 0 && h > 0) {
                if (x < x1) x1 = x
                if (y < y1) y1 = y
                if (x + w > x2) x2 = x + w
                if (y + h > y2) y2 = y + h
            }
        }
        if (x2 > x1 && y2 > y1) {
            synchronized(lock) {
                bitmap?.setPixels(pixels, y1 * fbW + x1, fbW, x1, y1, x2 - x1, y2 - y1)
            }
            listener.onFrame()
        }
        requestUpdate(true)
    }

    private fun readRaw(inp: DataInputStream, x: Int, y: Int, w: Int, h: Int) {
        val size = w * h * 4
        if (rawBuf.size < size) rawBuf = ByteArray(size)
        inp.readFully(rawBuf, 0, size)
        var p = 0
        for (row in 0 until h) {
            var di = (y + row) * fbW + x
            for (col in 0 until w) {
                pixels[di++] = alpha or
                    ((rawBuf[p + 2].toInt() and 0xFF) shl 16) or
                    ((rawBuf[p + 1].toInt() and 0xFF) shl 8) or
                    (rawBuf[p].toInt() and 0xFF)
                p += 4
            }
        }
    }

    private fun copyRect(sx: Int, sy: Int, x: Int, y: Int, w: Int, h: Int) {
        val tmp = IntArray(w * h)
        for (r in 0 until h) System.arraycopy(pixels, (sy + r) * fbW + sx, tmp, r * w, w)
        for (r in 0 until h) System.arraycopy(tmp, r * w, pixels, (y + r) * fbW + x, w)
    }

    private fun skipFully(inp: DataInputStream, n: Long) {
        var left = n
        val tmp = ByteArray(4096)
        while (left > 0) {
            val r = inp.read(tmp, 0, minOf(left, 4096L).toInt())
            if (r < 0) throw EOFException()
            left -= r
        }
    }

    private fun requestUpdate(incremental: Boolean) {
        val b = ByteArray(10)
        b[0] = 3
        b[1] = (if (incremental) 1 else 0).toByte()
        b[6] = (fbW shr 8).toByte(); b[7] = fbW.toByte()
        b[8] = (fbH shr 8).toByte(); b[9] = fbH.toByte()
        send(b)
    }

    fun pointer(x: Int, y: Int, mask: Int) {
        send(byteArrayOf(5, mask.toByte(), (x shr 8).toByte(), x.toByte(), (y shr 8).toByte(), y.toByte()))
    }

    fun key(sym: Int, down: Boolean) {
        send(
            byteArrayOf(
                4, (if (down) 1 else 0).toByte(), 0, 0,
                (sym shr 24).toByte(), (sym shr 16).toByte(), (sym shr 8).toByte(), sym.toByte()
            )
        )
    }

    private fun send(b: ByteArray) {
        if (!ready) return
        try {
            sender.execute {
                try { out?.write(b); out?.flush() } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    fun close() {
        running = false
        ready = false
        try { socket?.close() } catch (_: Exception) {}
        try { sender.shutdown() } catch (_: Exception) {}
    }
}
