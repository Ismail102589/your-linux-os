package com.yourlinux.os

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class VncView(ctx: Context) : View(ctx) {
    var client: VncClient? = null
    var bottomInset: Int = 0
        set(v) { field = v; invalidate() }

    var ctrl = false
    var alt = false
    var shift = false
    var onLatchChanged: (() -> Unit)? = null

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dest = RectF()
    private var scale = 1f
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val ui = Handler(Looper.getMainLooper())

    private enum class Mode { NONE, PENDING, DRAG, SCROLL }
    private var mode = Mode.NONE
    private var startX = 0f
    private var startY = 0f
    private var lastFx = 0
    private var lastFy = 0
    private var longPressed = false
    private var scrollY0 = 0f
    private var scrollAcc = 0f

    private val longPress = Runnable {
        if (mode == Mode.PENDING) {
            longPressed = true
            client?.pointer(lastFx, lastFy, 4)
            client?.pointer(lastFx, lastFy, 0)
            performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        }
    }

    init {
        setBackgroundColor(Color.BLACK)
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val c = client ?: return
        synchronized(c.lock) {
            val bmp = c.bitmap ?: return
            val aw = width.toFloat()
            val ah = (height - bottomInset).toFloat()
            scale = min(aw / bmp.width, ah / bmp.height)
            val dw = bmp.width * scale
            val dh = bmp.height * scale
            val dx = (aw - dw) / 2f
            val dy = (ah - dh) / 2f
            dest.set(dx, dy, dx + dw, dy + dh)
            canvas.drawBitmap(bmp, null, dest, paint)
        }
    }

    private fun fbX(x: Float): Int {
        val w = client?.bitmap?.width ?: 1
        return ((x - dest.left) / scale).toInt().coerceIn(0, w - 1)
    }

    private fun fbY(y: Float): Int {
        val h = client?.bitmap?.height ?: 1
        return ((y - dest.top) / scale).toInt().coerceIn(0, h - 1)
    }

    private fun avgY(e: MotionEvent): Float {
        var s = 0f
        for (i in 0 until e.pointerCount) s += e.getY(i)
        return s / e.pointerCount
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val c = client ?: return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = Mode.PENDING
                longPressed = false
                startX = e.x; startY = e.y
                lastFx = fbX(e.x); lastFy = fbY(e.y)
                c.pointer(lastFx, lastFy, 0)
                ui.postDelayed(longPress, 550)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                ui.removeCallbacks(longPress)
                if (mode == Mode.DRAG) c.pointer(lastFx, lastFy, 0)
                mode = Mode.SCROLL
                scrollY0 = avgY(e)
                scrollAcc = 0f
            }
            MotionEvent.ACTION_MOVE -> when (mode) {
                Mode.PENDING -> if (hypot(e.x - startX, e.y - startY) > slop) {
                    ui.removeCallbacks(longPress)
                    mode = Mode.DRAG
                    c.pointer(lastFx, lastFy, 1)
                    lastFx = fbX(e.x); lastFy = fbY(e.y)
                    c.pointer(lastFx, lastFy, 1)
                }
                Mode.DRAG -> {
                    lastFx = fbX(e.x); lastFy = fbY(e.y)
                    c.pointer(lastFx, lastFy, 1)
                }
                Mode.SCROLL -> {
                    val y = avgY(e)
                    scrollAcc += y - scrollY0
                    scrollY0 = y
                    val step = 40f
                    while (scrollAcc > step) { wheel(c, 8); scrollAcc -= step }
                    while (scrollAcc < -step) { wheel(c, 16); scrollAcc += step }
                }
                else -> {}
            }
            MotionEvent.ACTION_UP -> {
                ui.removeCallbacks(longPress)
                when (mode) {
                    Mode.PENDING -> if (!longPressed) {
                        c.pointer(lastFx, lastFy, 1)
                        c.pointer(lastFx, lastFy, 0)
                    }
                    Mode.DRAG -> c.pointer(lastFx, lastFy, 0)
                    else -> {}
                }
                mode = Mode.NONE
            }
            MotionEvent.ACTION_CANCEL -> {
                ui.removeCallbacks(longPress)
                if (mode == Mode.DRAG) c.pointer(lastFx, lastFy, 0)
                mode = Mode.NONE
            }
        }
        return true
    }

    private fun wheel(c: VncClient, mask: Int) {
        c.pointer(lastFx, lastFy, mask)
        c.pointer(lastFx, lastFy, 0)
    }

    // ---------- কীবোর্ড ----------

    fun tapKey(sym: Int) {
        val c = client ?: return
        if (sym == 0) return
        val mods = ArrayList<Int>()
        if (ctrl) mods.add(Keys.CTRL)
        if (alt) mods.add(Keys.ALT)
        if (shift) mods.add(Keys.SHIFT)
        for (m in mods) c.key(m, true)
        c.key(sym, true)
        c.key(sym, false)
        for (m in mods.asReversed()) c.key(m, false)
        if (mods.isNotEmpty()) {
            ctrl = false; alt = false; shift = false
            onLatchChanged?.invoke()
        }
    }

    private fun typeText(text: CharSequence) {
        var i = 0
        while (i < text.length) {
            val cp = Character.codePointAt(text, i)
            tapKey(Keys.forChar(cp))
            i += Character.charCount(cp)
        }
    }

    fun toggleKeyboard() {
        requestFocus()
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0)
    }

    override fun onCheckIsTextEditor(): Boolean = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_FULLSCREEN or
            EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_ACTION_NONE
        return object : BaseInputConnection(this, false) {
            private var composing: CharSequence? = null

            override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
                composing = null
                if (text != null) typeText(text)
                return true
            }

            override fun setComposingText(text: CharSequence?, newCursorPosition: Int): Boolean {
                composing = text
                return true
            }

            override fun finishComposingText(): Boolean {
                composing?.let { typeText(it) }
                composing = null
                return true
            }

            override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
                if (composing != null && composing!!.isNotEmpty()) {
                    composing = null
                    return true
                }
                repeat(max(beforeLength, 1).coerceAtMost(50)) { tapKey(Keys.BACKSPACE) }
                repeat(afterLength.coerceAtMost(50)) { tapKey(Keys.DELETE) }
                return true
            }

            override fun sendKeyEvent(event: KeyEvent): Boolean {
                if (event.action == KeyEvent.ACTION_DOWN) {
                    val sym = Keys.fromAndroid(event.keyCode)
                    if (sym != 0) tapKey(sym)
                    else {
                        val u = event.getUnicodeChar(0)
                        if (u != 0) tapKey(Keys.forChar(u))
                    }
                }
                return true
            }
        }
    }

    // হার্ডওয়্যার কীবোর্ড
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) return false
        return hwKey(keyCode, event, true)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) return false
        return hwKey(keyCode, event, false)
    }

    private fun hwKey(keyCode: Int, event: KeyEvent, down: Boolean): Boolean {
        val c = client ?: return false
        var sym = Keys.fromAndroid(keyCode)
        if (sym == 0) {
            val u = event.getUnicodeChar(0)
            if (u != 0) sym = Keys.forChar(u)
        }
        if (sym == 0) return false
        c.key(sym, down)
        return true
    }
}
