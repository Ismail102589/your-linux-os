package com.yourlinux.os

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.view.inputmethod.InputMethodManager
import android.widget.Toast

class DesktopActivity : Activity() {
    private lateinit var vnc: VncView
    private lateinit var info: TextView
    private lateinit var bar: HorizontalScrollView
    private lateinit var ctrlBtn: TextView
    private lateinit var altBtn: TextView
    private lateinit var shiftBtn: TextView
    private var client: VncClient? = null
    private var retries = 0
    private var closing = false
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        vnc = VncView(this)
        root.addView(vnc, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        info = TextView(this).apply {
            text = "ডেস্কটপে সংযোগ হচ্ছে…"
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(info, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // টুলবার (উপরে, কারণ টাস্কবার নিচে)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                row.addView(chip("Esc") { vnc.tapKey(Keys.ESC) })
        row.addView(chip("Tab") { vnc.tapKey(Keys.TAB) })
        ctrlBtn = chip("Ctrl") { vnc.ctrl = !vnc.ctrl; refreshLatch() }
        altBtn = chip("Alt") { vnc.alt = !vnc.alt; refreshLatch() }
        shiftBtn = chip("Shift") { vnc.shift = !vnc.shift; refreshLatch() }
        row.addView(ctrlBtn); row.addView(altBtn); row.addView(shiftBtn)
        row.addView(chip("←") { vnc.tapKey(Keys.LEFT) })
        row.addView(chip("↑") { vnc.tapKey(Keys.UP) })
        row.addView(chip("↓") { vnc.tapKey(Keys.DOWN) })
        row.addView(chip("→") { vnc.tapKey(Keys.RIGHT) })
        row.addView(chip("Del") { vnc.tapKey(Keys.DELETE) })
        row.addView(chip("⋮ মেনু") { showMenu() })
        vnc.onLatchChanged = { runOnUiThread { refreshLatch() } }

        bar = HorizontalScrollView(this).apply {
            setBackgroundColor(Color.argb(210, 25, 25, 25))
            visibility = View.GONE
            addView(row)
        }
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44), Gravity.TOP).apply {
            rightMargin = dp(96)
        })

        val toggle = chip("☰") {
            bar.visibility = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        toggle.setBackgroundColor(Color.argb(150, 25, 25, 25))
        root.addView(toggle, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.END))

        // সবসময় দেখা যাবে: কীবোর্ড বাটন
        val kb = chip("⌨") { toggleKeyboard() }
        kb.setBackgroundColor(Color.argb(150, 25, 25, 25))
        kb.textSize = 18f
        root.addView(kb, FrameLayout.LayoutParams(dp(48), dp(44), Gravity.TOP or Gravity.END).apply {
            rightMargin = dp(48)
        })

        setContentView(root)

        // কীবোর্ড খুললে ডেস্কটপ উপরে ছোট হয়ে আসবে
        root.viewTreeObserver.addOnGlobalLayoutListener {
            val r = Rect()
            root.getWindowVisibleDisplayFrame(r)
            val full = root.rootView.height
            val kb = full - r.bottom
            vnc.bottomInset = if (kb > full * 0.15f) kb else 0
        }
        hideSystemUi()
        connect()
    }

    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 14f
        gravity = Gravity.CENTER
        minWidth = dp(44)
        setPadding(dp(12), 0, dp(12), 0)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44))
        setOnClickListener { onClick() }
    }

    private fun toggleKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        if (vnc.bottomInset > 0) {
            imm.hideSoftInputFromWindow(vnc.windowToken, 0)
            return
        }
        vnc.requestFocus()
        imm.restartInput(vnc)
        ui.postDelayed({
            @Suppress("DEPRECATION")
            imm.showSoftInput(vnc, InputMethodManager.SHOW_FORCED)
        }, 120)
    }

    private fun refreshLatch() {
        ctrlBtn.setBackgroundColor(if (vnc.ctrl) Color.parseColor("#1565C0") else Color.TRANSPARENT)
        altBtn.setBackgroundColor(if (vnc.alt) Color.parseColor("#1565C0") else Color.TRANSPARENT)
        shiftBtn.setBackgroundColor(if (vnc.shift) Color.parseColor("#1565C0") else Color.TRANSPARENT)
    }

    private fun showMenu() {
        AlertDialog.Builder(this)
            .setItems(arrayOf("আবার সংযোগ", "ব্যাকগ্রাউন্ডে পাঠান", "Linux বন্ধ করুন")) { _, which ->
                when (which) {
                    0 -> { retries = 0; connect() }
                    1 -> moveTaskToBack(true)
                    2 -> stopLinux()
                }
            }.show()
    }

    private fun stopLinux() {
        closing = true
        startForegroundService(Intent(this, LinuxService::class.java).setAction(LinuxService.ACTION_STOP))
        finishAffinity()
    }

    private fun connect() {
        client?.close()
        info.visibility = View.VISIBLE
        info.text = "ডেস্কটপে সংযোগ হচ্ছে…"
        val c = VncClient("127.0.0.1", LinuxService.VNC_PORT, object : VncClient.Listener {
            override fun onConnected(width: Int, height: Int) {
                retries = 0
                runOnUiThread { info.visibility = View.GONE; vnc.invalidate() }
            }
            override fun onFrame() { vnc.postInvalidate() }
            override fun onDisconnected(reason: String) {
                runOnUiThread { handleDisconnect(reason) }
            }
        })
        client = c
        vnc.client = c
        c.start()
    }

    private fun handleDisconnect(reason: String) {
        if (closing || isFinishing) return
        val alive = SessionState.phase == Phase.RUNNING
        if (alive && retries < 5) {
            retries++
            info.visibility = View.VISIBLE
            info.text = "সংযোগ ছিঁড়ে গেছে, আবার চেষ্টা হচ্ছে ($retries)…"
            ui.postDelayed({ if (!closing && !isFinishing) connect() }, 1500)
        } else {
            Toast.makeText(this, "ডেস্কটপ বন্ধ: $reason", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SplashActivity::class.java))
            finish()
        }
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }

    override fun onDestroy() {
        closing = true
        client?.close()
        super.onDestroy()
    }
}
